import {
  aesDecrypt,
  aesEncrypt,
  generateRsaKeyPair,
  rsaDecrypt,
  rsaEncrypt,
} from '../src/crypto.js'
import { DecryptionError, EncryptionError } from '../src/types.js'

describe('RSA', () => {
  let privateKeyPem: string
  let publicKeyPem: string

  beforeAll(async () => {
    const kp = await generateRsaKeyPair()
    privateKeyPem = kp.privateKeyPem
    publicKeyPem = kp.publicKeyPem
  }, 30_000)

  test('roundtrip: encrypt then decrypt gives back original string', async () => {
    const message = 'hello RSA world'
    const ciphertext = await rsaEncrypt(publicKeyPem, message)
    const plaintext = await rsaDecrypt(privateKeyPem, ciphertext)
    expect(plaintext).toBe(message)
  })

  test('wrong key raises DecryptionError', async () => {
    const { privateKeyPem: otherPriv } = await generateRsaKeyPair()
    const ciphertext = await rsaEncrypt(publicKeyPem, 'secret')
    await expect(rsaDecrypt(otherPriv, ciphertext)).rejects.toBeInstanceOf(DecryptionError)
  }, 30_000)
})

describe('AES', () => {
  const txnKey = '550e8400-e29b-41d4-a716-446655440000'

  test('roundtrip: encrypt then decrypt gives back original bytes', async () => {
    const plaintext = new TextEncoder().encode('hello AES world')
    const ciphertext = await aesEncrypt(plaintext, txnKey)
    const decrypted = await aesDecrypt(ciphertext, txnKey)
    expect(decrypted).toEqual(plaintext)
  })

  test('wire format: valid base64, IV is first 12 bytes', async () => {
    const plaintext = new TextEncoder().encode('wire format test')
    const b64 = await aesEncrypt(plaintext, txnKey)

    // Must be valid base64
    expect(() => atob(b64)).not.toThrow()

    const wire = Uint8Array.from(atob(b64), c => c.charCodeAt(0))
    // wire = iv(12) + ciphertext + tag(16), so minimum length = 12 + 0 + 16
    expect(wire.length).toBeGreaterThanOrEqual(12 + plaintext.length + 16)
  })

  test('tampered ciphertext raises DecryptionError (GCM auth tag failure)', async () => {
    const plaintext = new TextEncoder().encode('tamper me')
    const b64 = await aesEncrypt(plaintext, txnKey)

    const wire = Array.from(Uint8Array.from(atob(b64), c => c.charCodeAt(0)))
    // Flip a byte in the ciphertext region (after the 12-byte IV)
    wire[12] ^= 0xff
    const tampered = btoa(String.fromCharCode(...wire))

    await expect(aesDecrypt(tampered, txnKey)).rejects.toBeInstanceOf(DecryptionError)
  })

  test('cross-language wire format: identical layout to Python (iv[12]+ciphertext+tag[16])', async () => {
    // Verify the base64(iv + ciphertext + tag) layout is consistent so Python can decrypt
    const plaintext = new TextEncoder().encode('cross-lang')
    const b64 = await aesEncrypt(plaintext, txnKey)
    const wire = Uint8Array.from(atob(b64), c => c.charCodeAt(0))

    const iv = wire.slice(0, 12)
    const ciphertextAndTag = wire.slice(12)

    // GCM tag is 16 bytes; ciphertext length equals plaintext length
    expect(ciphertextAndTag.length).toBe(plaintext.length + 16)
    expect(iv.length).toBe(12)

    // Round-trip must still work, confirming the layout interpretation
    const decrypted = await aesDecrypt(b64, txnKey)
    expect(decrypted).toEqual(plaintext)
  })
})
