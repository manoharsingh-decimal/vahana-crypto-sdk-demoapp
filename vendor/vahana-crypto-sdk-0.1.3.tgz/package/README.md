# vahana-crypto-sdk — TypeScript SDK

Frontend component of the Vahana end-to-end encryption SDK. Manages the
handshake with the Python backend, encrypts payloads before sending them over
HTTP, and decrypts responses. Uses the **Web Crypto API** exclusively — works
in browsers, Deno, and Node ≥ 18 with no native dependencies.

---

## Installation

```bash
npm install vahana-crypto-sdk
```

---

## Quick-start

```typescript
import {
  VahanaCryptoSdk,
  FrontendSdkConfig,
  SdkError,
  HandshakeFailedError,
} from 'vahana-crypto-sdk'

// 1. Configure the SDK once (e.g., at app startup)
const config: FrontendSdkConfig = {
  baseUri: 'https://api.example.com',
  handshakeEndpoint: '/crypto/handshake',
  longLivedPublicKey: PUBLIC_KEY_PEM,   // the server's long-lived RSA public key
  txnKeyName: 'txnKey',                  // must match backend config
  payloadKeyName: 'payload',             // must match backend config
}

const sdk = new VahanaCryptoSdk(config)

// 2. Encrypt payloads before your API call
const { encPayloads, encTxnKey, cryptoSessionId } = await sdk.doEncryption([
  { type: 'STRING', value: JSON.stringify({ userId: 42, action: 'transfer' }) },
  { type: 'BINARY', value: someArrayBuffer },
])

// 3. Call your API endpoint with the encrypted envelope
const response = await fetch('https://api.example.com/transfer', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ encPayloads, encTxnKey, cryptoSessionId }),
})

const { encPayloads: respPayloads, encTxnKey: respTxnKey } = await response.json()

// 4. Decrypt the response
const decrypted = await sdk.doDecryption(respPayloads, respTxnKey)
// decrypted: [{ type: 'STRING', value: string }, ...]

console.log(decrypted[0].value) // e.g., "transfer complete"
```

The first call to `doEncryption` (or any method that needs the session) will
automatically perform the handshake — no explicit `await sdk.ensureHandshake()`
is needed in normal usage.

---

## Session store selection guide

The TypeScript SDK is stateless with respect to persistent storage — all session
state is held in the `VahanaCryptoSdk` instance in memory. To share a session
across page reloads, create a new `VahanaCryptoSdk` instance per page load
(or per logical session); the handshake is fast (~200ms on modern hardware).

For multi-tab applications, each tab should have its own `VahanaCryptoSdk`
instance. The backend session store (Redis / Postgres) will garbage-collect
expired sessions automatically.

---

## Error handling

All SDK errors inherit from `SdkError` (which extends `Error`). Each error has
an optional `cause` property with the underlying Web Crypto exception:

```typescript
import {
  SdkError,
  HandshakeFailedError,   // handshake HTTP call failed or returned an error
  DecryptionError,        // RSA or AES decryption failed (tampered data, wrong key)
  EncryptionError,        // RSA or AES encryption failed
  InvalidEnvelopeError,   // missing txnKey or payload field in response
  SessionNotFoundError,   // session ID not found (shouldn't happen on the TS side)
} from 'vahana-crypto-sdk'

try {
  const result = await sdk.doEncryption(payloads)
} catch (e) {
  if (e instanceof HandshakeFailedError) {
    // The handshake failed — the SDK is now in a terminal FAILED state.
    // Create a new VahanaCryptoSdk instance to retry.
    console.error('Handshake failed:', e.message, e.cause)
  } else if (e instanceof SdkError) {
    console.error('SDK error:', e.message)
  } else {
    throw e   // unexpected — re-throw
  }
}
```

**Important:** Once the handshake transitions to `FAILED`, all subsequent calls
on that instance will immediately reject. Create a new `VahanaCryptoSdk`
instance to start a fresh session.

---

## Security notes

**Long-lived public key** — The server's long-lived RSA public key (`4096-bit`)
is the only key that needs to be distributed to clients. It is used only to
wrap the handshake transaction key; the actual payload encryption key is derived
from an ephemeral keypair generated fresh for each session.

**No key material in logs** — The SDK never logs keys, plaintext payloads, or
transaction keys. Avoid logging `encTxnKey`, `encPayloads`, or raw response
bodies in your application layer.

**One-time transaction keys** — Every call to `doEncryption` generates a fresh
UUID transaction key. Keys are never reused between requests.

**AES-GCM authentication** — The GCM authentication tag is always verified on
decryption. A tampered or corrupted ciphertext will cause `doDecryption` to
reject with `DecryptionError` — the plaintext is never returned.

**Session TTL** — Backend sessions expire after 1 hour by default (configurable
in the session store). If the user's session expires mid-flow, `doEncryption`
will return a `SessionNotFoundError` from the backend (propagated as a 4xx HTTP
error in your application). Handle this by starting a new SDK instance.
