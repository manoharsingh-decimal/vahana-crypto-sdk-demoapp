import { DecryptionError, EncryptionError } from './types.js'

const subtle = globalThis.crypto.subtle

// ---------------------------------------------------------------------------
// PEM helpers
// ---------------------------------------------------------------------------

export function pemToArrayBuffer(pem: string): ArrayBuffer {
  const base64 = pem
    .replace(/-----BEGIN [^-]+-----/, '')
    .replace(/-----END [^-]+-----/, '')
    .replace(/\s/g, '')
  const binary = atob(base64)
  const buffer = new ArrayBuffer(binary.length)
  const view = new Uint8Array(buffer)
  for (let i = 0; i < binary.length; i++) {
    view[i] = binary.charCodeAt(i)
  }
  return buffer
}

export function arrayBufferToPem(
  buffer: ArrayBuffer,
  type: 'PUBLIC KEY' | 'PRIVATE KEY'
): string {
  const bytes = new Uint8Array(buffer)
  let binary = ''
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  const base64 = btoa(binary)
  const lines = base64.match(/.{1,64}/g)?.join('\n') ?? base64
  return `-----BEGIN ${type}-----\n${lines}\n-----END ${type}-----`
}

function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = ''
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary)
}

function base64ToUint8Array(b64: string): Uint8Array {
  const binary = atob(b64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  return bytes
}

// ---------------------------------------------------------------------------
// RSA keypair generation
// ---------------------------------------------------------------------------

export async function generateRsaKeyPair(): Promise<{
  privateKeyPem: string
  publicKeyPem: string
}> {
  const keyPair = await subtle.generateKey(
    {
      name: 'RSA-OAEP',
      modulusLength: 4096,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true,
    ['encrypt', 'decrypt']
  )
  const publicKeyBuffer = await subtle.exportKey('spki', keyPair.publicKey)
  const privateKeyBuffer = await subtle.exportKey('pkcs8', keyPair.privateKey)
  return {
    publicKeyPem: arrayBufferToPem(publicKeyBuffer, 'PUBLIC KEY'),
    privateKeyPem: arrayBufferToPem(privateKeyBuffer, 'PRIVATE KEY'),
  }
}

// ---------------------------------------------------------------------------
// RSA encrypt / decrypt (OAEP SHA-256)
// ---------------------------------------------------------------------------

export async function rsaEncrypt(
  publicKeyPem: string,
  plaintext: string
): Promise<string> {
  try {
    const keyBuffer = pemToArrayBuffer(publicKeyPem)
    const key = await subtle.importKey(
      'spki',
      keyBuffer,
      { name: 'RSA-OAEP', hash: 'SHA-256' },
      false,
      ['encrypt']
    )
    const plaintextBytes = new TextEncoder().encode(plaintext)
    const ciphertext = await subtle.encrypt({ name: 'RSA-OAEP' }, key, plaintextBytes)
    return uint8ArrayToBase64(new Uint8Array(ciphertext))
  } catch (e) {
    throw new EncryptionError('RSA encryption failed', e)
  }
}

export async function rsaDecrypt(
  privateKeyPem: string,
  ciphertextB64: string
): Promise<string> {
  try {
    const keyBuffer = pemToArrayBuffer(privateKeyPem)
    const key = await subtle.importKey(
      'pkcs8',
      keyBuffer,
      { name: 'RSA-OAEP', hash: 'SHA-256' },
      false,
      ['decrypt']
    )
    const ciphertextBytes = base64ToUint8Array(ciphertextB64)
    const plaintext = await subtle.decrypt({ name: 'RSA-OAEP' }, key, ciphertextBytes.buffer as ArrayBuffer)
    return new TextDecoder().decode(plaintext)
  } catch (e) {
    throw new DecryptionError('RSA decryption failed', e)
  }
}

// ---------------------------------------------------------------------------
// AES-256-GCM encrypt / decrypt
// Wire format: base64(iv[12] + ciphertext + tag[16]) — identical to Python side
// ---------------------------------------------------------------------------

const AES_IV_LEN = 12

async function deriveAesKey(txnKey: string): Promise<CryptoKey> {
  const keyMaterial = new TextEncoder().encode(txnKey)
  const hashBuffer = await subtle.digest('SHA-256', keyMaterial)
  return subtle.importKey('raw', hashBuffer, { name: 'AES-GCM' }, false, [
    'encrypt',
    'decrypt',
  ])
}

export async function aesEncrypt(
  plaintextBytes: Uint8Array,
  txnKey: string
): Promise<string> {
  try {
    const key = await deriveAesKey(txnKey)
    const iv = globalThis.crypto.getRandomValues(new Uint8Array(AES_IV_LEN))
    // WebCrypto AES-GCM returns ciphertext + tag (tag is last 16 bytes)
    const ciphertextWithTag = await subtle.encrypt(
      { name: 'AES-GCM', iv, tagLength: 128 },
      key,
      plaintextBytes.buffer as ArrayBuffer
    )
    const wire = new Uint8Array(AES_IV_LEN + ciphertextWithTag.byteLength)
    wire.set(iv, 0)
    wire.set(new Uint8Array(ciphertextWithTag), AES_IV_LEN)
    return uint8ArrayToBase64(wire)
  } catch (e) {
    throw new EncryptionError('AES encryption failed', e)
  }
}

export async function aesDecrypt(
  ciphertextB64: string,
  txnKey: string
): Promise<Uint8Array> {
  try {
    const key = await deriveAesKey(txnKey)
    const wire = base64ToUint8Array(ciphertextB64)
    const iv = wire.slice(0, AES_IV_LEN)
    const ciphertextWithTag = wire.slice(AES_IV_LEN)
    const plaintext = await subtle.decrypt(
      { name: 'AES-GCM', iv, tagLength: 128 },
      key,
      ciphertextWithTag
    )
    return new Uint8Array(plaintext)
  } catch (e) {
    throw new DecryptionError('AES decryption failed', e)
  }
}

// ---------------------------------------------------------------------------
// RSA-PSS-SHA256 signing & verification
// ---------------------------------------------------------------------------

export async function rsaVerify(publicKeyPem: string, data: string, signatureB64: string): Promise<boolean> {
  try {
    const keyBuffer = pemToArrayBuffer(publicKeyPem)
    const key = await subtle.importKey(
      'spki',
      keyBuffer,
      { name: 'RSA-PSS', hash: 'SHA-256' },
      false,
      ['verify']
    )
    const sigBytes = base64ToUint8Array(signatureB64)
    return await subtle.verify(
      { name: 'RSA-PSS', saltLength: 32 },
      key,
      sigBytes.buffer as ArrayBuffer,
      new TextEncoder().encode(data)
    )
  } catch (e) {
    throw new DecryptionError('RSA verification failed', e)
  }
}

export async function rsaSign(privateKeyPem: string, data: string): Promise<string> {
  try {
    const keyBuffer = pemToArrayBuffer(privateKeyPem)
    const key = await subtle.importKey(
      'pkcs8',
      keyBuffer,
      { name: 'RSA-PSS', hash: 'SHA-256' },
      false,
      ['sign']
    )
    const dataBytes = new TextEncoder().encode(data)
    // salt length = 32 bytes (SHA-256 digest size)
    const signature = await subtle.sign({ name: 'RSA-PSS', saltLength: 32 }, key, dataBytes)
    return uint8ArrayToBase64(new Uint8Array(signature))
  } catch (e) {
    throw new EncryptionError('RSA signing failed', e)
  }
}
