import { aesDecrypt, aesEncrypt, rsaDecrypt, rsaEncrypt } from './crypto.js'
import { HandshakeManager } from './handshake.js'
import { SdkLogger } from './logger.js'
import { DecryptionError, EncryptedPayload, EncryptionResult, FrontendSdkConfig, Payload } from './types.js'


export class VahanaCryptoSdk {
  private readonly handshakeManager: HandshakeManager
  private readonly logger: SdkLogger

  constructor(config: FrontendSdkConfig) {
    this.logger = new SdkLogger(config.logLevel)
    this.handshakeManager = new HandshakeManager(config, this.logger)
  }

  // ------------------------------------------------------------------
  // Phase 3 — Frontend encrypts payloads for backend
  // ------------------------------------------------------------------

  async doEncryption(payloads: Payload[]): Promise<EncryptionResult>
  async doEncryption(payload: Blob): Promise<EncryptionResult>
  async doEncryption(payload: ArrayBuffer): Promise<EncryptionResult>
  async doEncryption(input: Payload[] | Blob | ArrayBuffer): Promise<EncryptionResult> {
    const payloads: Payload[] = Array.isArray(input)
      ? input
      : input instanceof Blob
        ? [{ type: 'BLOB', value: input }]
        : [{ type: 'BINARY', value: input as ArrayBuffer }]

    this.logger.debug('doEncryption —', payloads.length, 'payload(s)')
    const cryptoSessionId = await this.handshakeManager.ensureHandshake()
    const serverPub = this.handshakeManager.serverPub!

    const txnKey = globalThis.crypto.randomUUID()
    const encTxnKey = await rsaEncrypt(serverPub, txnKey)

    const encPayloads: EncryptedPayload[] = await Promise.all(
      payloads.map(async p => ({
        type: p.type,
        value: await aesEncrypt(await serializePayload(p), txnKey),
      }))
    )

    this.logger.trace('doEncryption — encPayloads:', encPayloads)
    return { encPayloads, encTxnKey, cryptoSessionId }
  }

  // ------------------------------------------------------------------
  // Phase 4 — Frontend decrypts backend response
  // ------------------------------------------------------------------

  async doDecryption(encPayloads: EncryptedPayload[], encTxnKey: string): Promise<Payload[]> {
    this.logger.debug('doDecryption —', encPayloads.length, 'payload(s)')
    const clientPriv = this.handshakeManager.clientPriv
    if (!clientPriv) throw new DecryptionError('Session state invalid: clientPriv not present')

    const txnKey = await rsaDecrypt(clientPriv, encTxnKey)

    return Promise.all(
      encPayloads.map(async item => {
        const data = await aesDecrypt(item.value, txnKey)
        const type = item.type ?? 'STRING'
        return type === 'STRING'
          ? { type, value: new TextDecoder().decode(data) }
          : { type, value: data.buffer as ArrayBuffer }
      })
    )
  }

}

async function serializePayload(p: Payload): Promise<Uint8Array> {
  if (p.type === 'STRING') return new TextEncoder().encode(p.value as string)
  if (p.type === 'BINARY') return new Uint8Array(p.value as ArrayBuffer)
  return new Uint8Array(await (p.value as Blob).arrayBuffer())
}
