export class SdkError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message)
    this.name = 'SdkError'
  }
}

export class SessionNotFoundError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super(message, cause)
    this.name = 'SessionNotFoundError'
  }
}

export class DecryptionError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super(message, cause)
    this.name = 'DecryptionError'
  }
}

export class EncryptionError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super(message, cause)
    this.name = 'EncryptionError'
  }
}

export class InvalidEnvelopeError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super(message, cause)
    this.name = 'InvalidEnvelopeError'
  }
}

export class HandshakeFailedError extends SdkError {
  constructor(message: string, cause?: unknown) {
    super(message, cause)
    this.name = 'HandshakeFailedError'
  }
}

export type Payload = {
  type: 'BLOB' | 'BINARY' | 'STRING'
  value: any
}

export type EncryptedPayload = {
  type?: 'BLOB' | 'BINARY' | 'STRING'
  value: string
}

export type EncryptionResult = {
  encPayloads: EncryptedPayload[]
  encTxnKey: string
  cryptoSessionId: string
}

/** T2 variant — no encTxnKey; both sides use the shared txnKeyS established at handshake. */
export type EncryptionResultV2 = {
  encPayloads: EncryptedPayload[]
  cryptoSessionId: string
}

export type FrontendSdkConfig = {
  baseUri: string
  handshakeEndpoint: string
  publicKey: string
  txnKeyName: string
  payloadKeyName: string
}
