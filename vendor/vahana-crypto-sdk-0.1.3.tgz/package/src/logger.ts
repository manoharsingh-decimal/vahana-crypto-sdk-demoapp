// Logger removed — handshake diagnostics are now emitted via structured console groups directly.
