import { LogLevel } from './types.js'

const RANK: Record<LogLevel, number> = {
  trace: 0,
  debug: 1,
  info:  2,
  warn:  3,
  error: 4,
  none:  5,
}

export class SdkLogger {
  private readonly rank: number

  constructor(level: LogLevel = 'info') {
    this.rank = RANK[level] ?? RANK.info
  }

  isEnabled(level: LogLevel): boolean {
    return this.rank <= RANK[level]
  }

  trace(...args: unknown[]): void { if (this.rank <= 0) console.debug('[sdk:trace]', ...args) }
  debug(...args: unknown[]): void { if (this.rank <= 1) console.debug('[sdk:debug]', ...args) }
  info(...args: unknown[]): void  { if (this.rank <= 2) console.info('[sdk:info]',  ...args) }
  warn(...args: unknown[]): void  { if (this.rank <= 3) console.warn('[sdk:warn]',  ...args) }
  error(...args: unknown[]): void { if (this.rank <= 4) console.error('[sdk:error]', ...args) }
}
