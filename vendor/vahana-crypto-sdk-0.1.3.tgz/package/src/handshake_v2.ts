import { aesDecrypt, aesEncrypt, generateRsaKeyPair, rsaDecrypt, rsaEncrypt, rsaVerify } from './crypto.js'
import { FrontendSdkConfig, HandshakeFailedError } from './types.js'

type HandshakeState = 'NOT_STARTED' | 'IN_PROGRESS' | 'SUCCESS' | 'FAILED'

type Listener = {
  resolve: (sessionId: string) => void
  reject: (err: HandshakeFailedError) => void
}

function randomHex(length: number): string {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(Math.ceil(length / 2)))
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, length)
}

async function browserFingerprint(): Promise<string> {
  const raw = [
    navigator.userAgent,
    navigator.language,
    navigator.languages?.join(',') ?? '',
    String(screen.width),
    String(screen.height),
    String(screen.colorDepth),
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    String(navigator.hardwareConcurrency ?? ''),
    navigator.platform ?? '',
  ].join('|')

  const buffer = await globalThis.crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(raw),
  )
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

const C_SDK = 'color: #a78bfa; font-weight: bold'
const C_HS  = 'color: #fb923c'
const C_REQ = 'color: #38bdf8'
const C_RES = 'color: #4ade80'
const C_DIM = 'color: #94a3b8'

export class HandshakeManagerV2 {
  private state: HandshakeState = 'NOT_STARTED'
  private listeners: Listener[] = []

  sessionId: string | null = null
  txnKeyS: string | null = null
  lastReqPayload: Record<string, unknown> | null = null
  lastRespPayload: Record<string, unknown> | null = null

  constructor(private readonly config: FrontendSdkConfig) {}

  async ensureHandshake(): Promise<string> {
    if (this.state === 'SUCCESS') return this.sessionId!
    if (this.state === 'FAILED') throw new HandshakeFailedError('Handshake is in FAILED state')
    if (this.state === 'IN_PROGRESS') {
      return new Promise<string>((resolve, reject) => {
        this.listeners.push({ resolve, reject })
      })
    }

    this.state = 'IN_PROGRESS'
    try {
      const { privateKeyPem: clientPriv, publicKeyPem: clientPub } = await generateRsaKeyPair()

      const txnKey = globalThis.crypto.randomUUID()
      const guid = await browserFingerprint()
      const nonce = `${Date.now()}-${randomHex(16)}`

      const clientPubB64 = btoa(clientPub)
      const payload = { guid, nonce, clientPubKey: clientPubB64 }
      this.lastReqPayload = { guid, nonce, clientPubKey: clientPubB64.slice(0, 40) + '…' }

      const encKey = await rsaEncrypt(this.config.publicKey, txnKey)
      const encPayload = await aesEncrypt(
        new TextEncoder().encode(JSON.stringify(payload)),
        txnKey
      )

      const wireReq = {
        [this.config.txnKeyName]: encKey,
        [this.config.payloadKeyName]: encPayload,
      }

      const url = this.config.baseUri + this.config.handshakeEndpoint
      const httpResp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(wireReq),
      })

      if (!httpResp.ok) throw new Error(`Handshake HTTP error: ${httpResp.status}`)

      const wireRes = await httpResp.json()

      // Backend sends txnKeyS RSA-encrypted under clientPub, payload AES-encrypted under txnKeyS
      this.txnKeyS = await rsaDecrypt(clientPriv, wireRes[this.config.txnKeyName])
      const raw = await aesDecrypt(wireRes[this.config.payloadKeyName], this.txnKeyS)
      const respPayload = JSON.parse(new TextDecoder().decode(raw))
      this.lastRespPayload = {
        cryptoSessionId: respPayload.cryptoSessionId,
        signedNonce: respPayload.signedNonce,
      }

      // Verify nonce signature against the long-lived server public key
      const valid = await rsaVerify(this.config.publicKey, nonce, respPayload.signedNonce)
      if (!valid) throw new Error('Nonce signature verification failed — possible MITM')

      this.sessionId = respPayload.cryptoSessionId
      this.state = 'SUCCESS'

      console.groupCollapsed('%c[Vahana SDK] %chandshake %s', C_SDK, C_HS, url)
      console.log('%c→ wire req',      C_REQ, wireReq)
      console.log('%c→ decrypted req', C_REQ, this.lastReqPayload)
      console.log('%c← wire res',      C_RES, wireRes)
      console.log('%c← decrypted res', C_RES, this.lastRespPayload)
      console.log('%ctxnKeyS',   C_DIM, this.txnKeyS)
      console.log('%csessionId', C_DIM, this.sessionId)
      console.groupEnd()

      const id = this.sessionId!
      for (const l of this.listeners) l.resolve(id)
      this.listeners = []
      return id
    } catch (e) {
      this.state = 'FAILED'
      const err = new HandshakeFailedError('Handshake failed', e)
      for (const l of this.listeners) l.reject(err)
      this.listeners = []
      throw err
    }
  }
}
