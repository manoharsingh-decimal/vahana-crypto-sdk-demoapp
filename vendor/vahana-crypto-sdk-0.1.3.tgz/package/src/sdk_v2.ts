import { aesDecrypt, aesEncrypt } from './crypto.js'
import { HandshakeManagerV2 } from './handshake_v2.js'
import { SdkLogger } from './logger.js'
import { DecryptionError, EncryptedPayload, EncryptionResultV2, FrontendSdkConfig, Payload } from './types.js'


export class VahanaCryptoSdkV2 {
  private readonly handshakeManager: HandshakeManagerV2
  private readonly logger: SdkLogger

  constructor(config: FrontendSdkConfig) {
    this.logger = new SdkLogger(config.logLevel)
    this.handshakeManager = new HandshakeManagerV2(config, this.logger)
  }

  // ------------------------------------------------------------------
  // Phase 3 — Frontend encrypts payloads for backend  (AES-only)
  // ------------------------------------------------------------------

  async doEncryption(payloads: Payload[]): Promise<EncryptionResultV2>
  async doEncryption(payload: Blob): Promise<EncryptionResultV2>
  async doEncryption(payload: ArrayBuffer): Promise<EncryptionResultV2>
  async doEncryption(input: Payload[] | Blob | ArrayBuffer): Promise<EncryptionResultV2> {
    const payloads: Payload[] = Array.isArray(input)
      ? input
      : input instanceof Blob
        ? [{ type: 'BLOB', value: input }]
        : [{ type: 'BINARY', value: input as ArrayBuffer }]

    this.logger.debug('doEncryption —', payloads.length, 'payload(s)')
    const cryptoSessionId = await this.handshakeManager.ensureHandshake()
    const txnKeyS = this.handshakeManager.txnKeyS!

    const encPayloads: EncryptedPayload[] = await Promise.all(
      payloads.map(async p => ({
        type: p.type,
        value: await aesEncrypt(await serializePayload(p), txnKeyS),
      }))
    )

    this.logger.trace('doEncryption — encPayloads:', encPayloads)
    return { encPayloads, cryptoSessionId }
  }

  // ------------------------------------------------------------------
  // Phase 4 — Frontend decrypts backend response  (AES-only)
  // ------------------------------------------------------------------

  async doDecryption(encPayloads: EncryptedPayload[]): Promise<Payload[]> {
    this.logger.debug('doDecryption —', encPayloads.length, 'payload(s)')
    const txnKeyS = this.handshakeManager.txnKeyS
    if (!txnKeyS) throw new DecryptionError('Session state invalid: txnKeyS not present')

    return Promise.all(
      encPayloads.map(async item => {
        const data = await aesDecrypt(item.value, txnKeyS)
        const type = item.type ?? 'STRING'
        return type === 'STRING'
          ? { type, value: new TextDecoder().decode(data) }
          : { type, value: data.buffer as ArrayBuffer }
      })
    )
  }

}

async function serializePayload(p: Payload): Promise<Uint8Array> {
  if (p.type === 'STRING') return new TextEncoder().encode(p.value as string)
  if (p.type === 'BINARY') return new Uint8Array(p.value as ArrayBuffer)
  return new Uint8Array(await (p.value as Blob).arrayBuffer())
}
