class SdkException(Exception):
    """Base class for all SDK-originated errors."""

    def __init__(self, message: str, cause: Exception = None):
        super().__init__(message)
        self.cause = cause


class SessionNotFoundException(SdkException):
    """Session ID not found in CryptoSessionStore."""


class DecryptionException(SdkException):
    """RSA or AES decryption failed."""


class EncryptionException(SdkException):
    """RSA or AES encryption failed."""


class InvalidEnvelopeException(SdkException):
    """txnKey or payload field missing from request body."""


class HandshakeFailedException(SdkException):
    """Handshake is in FAILED state."""
