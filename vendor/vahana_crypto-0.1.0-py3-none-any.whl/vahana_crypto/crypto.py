import base64
import hashlib
import os

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .exceptions import DecryptionException, EncryptionException

_AES_IV_LEN = 12


def generate_rsa_keypair() -> tuple[str, str]:
    """Generate a 4096-bit RSA keypair. Returns (private_pem, public_pem)."""
    priv = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    pub_pem = priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    return priv_pem, pub_pem


def rsa_encrypt(pub_pem: str, plaintext: str) -> str:
    """Encrypt plaintext with RSA-OAEP-SHA256. Returns base64 ciphertext."""
    try:
        key = serialization.load_pem_public_key(pub_pem.encode("utf-8"))
        ct = key.encrypt(
            plaintext.encode("utf-8"),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        return base64.b64encode(ct).decode("utf-8")
    except Exception as e:
        raise EncryptionException("RSA encryption failed", cause=e) from e


def rsa_decrypt(priv_pem: str, ciphertext: str) -> str:
    """Decrypt base64 RSA-OAEP-SHA256 ciphertext. Returns plaintext string."""
    try:
        key = serialization.load_pem_private_key(priv_pem.encode("utf-8"), password=None)
        plaintext = key.decrypt(
            base64.b64decode(ciphertext),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        return plaintext.decode("utf-8")
    except Exception as e:
        raise DecryptionException("RSA decryption failed", cause=e) from e


def aes_encrypt(plaintext: bytes, txn_key: str) -> str:
    """
    Encrypt bytes with AES-256-GCM.
    txn_key UUID is SHA-256 hashed to produce the 32-byte key.
    Wire format: base64(iv[12] + ciphertext + tag[16]).
    """
    try:
        key = hashlib.sha256(txn_key.encode("utf-8")).digest()
        iv = os.urandom(_AES_IV_LEN)
        raw = AESGCM(key).encrypt(iv, plaintext, None)  # raw = ciphertext + tag
        return base64.b64encode(iv + raw).decode("utf-8")
    except Exception as e:
        raise EncryptionException("AES encryption failed", cause=e) from e


def aes_decrypt(ciphertext: str, txn_key: str) -> bytes:
    """
    Decrypt base64(iv[12] + ciphertext + tag[16]) with AES-256-GCM.
    txn_key UUID is SHA-256 hashed to produce the 32-byte key.
    """
    try:
        key = hashlib.sha256(txn_key.encode("utf-8")).digest()
        wire = base64.b64decode(ciphertext)
        return AESGCM(key).decrypt(wire[:_AES_IV_LEN], wire[_AES_IV_LEN:], None)
    except Exception as e:
        raise DecryptionException("AES decryption failed", cause=e) from e


def rsa_sign(priv_pem: str, data: str) -> str:
    """Sign data with RSA-PSS-SHA256. Returns base64 signature."""
    try:
        key = serialization.load_pem_private_key(priv_pem.encode("utf-8"), password=None)
        sig = key.sign(
            data.encode("utf-8"),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
        return base64.b64encode(sig).decode("utf-8")
    except Exception as e:
        raise EncryptionException("RSA signing failed", cause=e) from e


def rsa_sign_v2(priv_pem: str, data: str) -> str:
    """Sign with RSA-PSS-SHA256, salt_length=32 — cross-platform compatible with WebCrypto."""
    try:
        key = serialization.load_pem_private_key(priv_pem.encode("utf-8"), password=None)
        sig = key.sign(
            data.encode("utf-8"),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        return base64.b64encode(sig).decode("utf-8")
    except Exception as e:
        raise EncryptionException("RSA signing failed", cause=e) from e


def rsa_verify(pub_pem: str, data: str, signature_b64: str) -> bool:
    """Verify an RSA-PSS-SHA256 signature (salt_length=32). Returns True if valid, False if invalid."""
    from cryptography.exceptions import InvalidSignature
    try:
        key = serialization.load_pem_public_key(pub_pem.encode("utf-8"))
        key.verify(
            base64.b64decode(signature_b64),
            data.encode("utf-8"),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        return False
    except Exception as e:
        raise DecryptionException("RSA verification failed", cause=e) from e
