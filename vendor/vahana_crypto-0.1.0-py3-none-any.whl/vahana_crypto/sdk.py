import base64
import json
import logging
import uuid

from .crypto import aes_decrypt, aes_encrypt, generate_rsa_keypair, rsa_decrypt, rsa_encrypt, rsa_sign
from .exceptions import InvalidEnvelopeException
from .session_store import CryptoSessionStore

logger = logging.getLogger(__name__)


class VahanaCryptoSdk:
    """
    Backend (Python) side of the Vahana crypto SDK.

    Constructor args:
        private_key   – PEM of the server long-lived RSA private key
        session_store – CryptoSessionStore implementation (injected)
        txn_key_name  – envelope field name for the encrypted txn key
        payload_key_name – envelope field name for the encrypted payload
    """

    def __init__(
        self,
        private_key: str,
        session_store: CryptoSessionStore,
        txn_key_name: str = "txnKey",
        payload_key_name: str = "payload",
        log_level: str = "INFO",
    ):
        self._priv = private_key
        self._store = session_store
        self._txn_key_name = txn_key_name
        self._payload_key_name = payload_key_name
        logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # ------------------------------------------------------------------
    # Phase 2 — Handshake
    # ------------------------------------------------------------------

    def do_handshake(self, request_body: dict) -> dict:
        """
        Process a handshake request from the frontend.
        Returns the encrypted response dict to send back as-is.
        """
        logger.debug("Handshake started")
        enc_key = request_body.get(self._txn_key_name)
        enc_payload = request_body.get(self._payload_key_name)
        if enc_key is None or enc_payload is None:
            logger.error("Handshake rejected: missing envelope fields")
            raise InvalidEnvelopeException(
                f"Missing required envelope fields: '{self._txn_key_name}' or '{self._payload_key_name}'"
            )

        txn_key = rsa_decrypt(self._priv, enc_key)
        payload = json.loads(aes_decrypt(enc_payload, txn_key))

        guid = payload["guid"]
        nonce = payload["nonce"]
        client_pub = base64.b64decode(payload["clientPubKey"]).decode("utf-8")

        session_id = str(uuid.uuid1())
        server_priv, server_pub = generate_rsa_keypair()

        self._store.set(session_id, {
            "server_priv_key": server_priv,
            "client_pub_key": client_pub,
            "guid": guid,
        })
        logger.info("Handshake complete — session_id=%s guid=%s", session_id, guid)

        resp = {
            "serverPubKey": base64.b64encode(server_pub.encode("utf-8")).decode("utf-8"),
            "cryptoSessionId": session_id,
            "signedNonce": rsa_sign(server_priv, nonce),
        }

        resp_key = str(uuid.uuid4())
        return {
            self._txn_key_name: rsa_encrypt(client_pub, resp_key),
            self._payload_key_name: aes_encrypt(json.dumps(resp).encode("utf-8"), resp_key),
        }

    # ------------------------------------------------------------------
    # Phase 3 — Decrypt frontend payloads
    # ------------------------------------------------------------------

    def do_decryption(self, enc_payloads: list, session_id: str, enc_key: str) -> list:
        """
        Decrypt payloads sent by the frontend.
        enc_payloads: list of {"type": "BLOB"|"BINARY"|"STRING", "value": base64_string}
        Returns list of {"type": ..., "value": bytes | str}
        """
        logger.debug("Decrypting %d payload(s) for session %s", len(enc_payloads), session_id)
        session = self._store.get(session_id)
        txn_key = rsa_decrypt(session["server_priv_key"], enc_key)

        result = []
        for item in enc_payloads:
            data = aes_decrypt(item["value"], txn_key)
            type_str = item.get("type")
            if type_str is None:
                try:
                    value = data.decode("utf-8")
                    type_str = "STRING"
                except UnicodeDecodeError:
                    value = data
                    type_str = "BINARY"
            else:
                value = data.decode("utf-8") if type_str == "STRING" else data
            result.append({"type": type_str, "value": value})
        return result

    # ------------------------------------------------------------------
    # Phase 4 — Encrypt response payloads for frontend
    # ------------------------------------------------------------------

    def do_encryption(self, payloads: list, session_id: str) -> dict:
        """
        Encrypt response payloads for the frontend.
        payloads: list of {"type": "BLOB"|"BINARY"|"STRING", "value": bytes | str}
        Returns {"encPayloads": [...], "encTxnKey": str, "cryptoSessionId": str}
        """
        logger.debug("Encrypting %d payload(s) for session %s", len(payloads), session_id)
        session = self._store.get(session_id)
        client_pub = session["client_pub_key"]

        txn_key = str(uuid.uuid4())
        enc_payloads = []
        for item in payloads:
            data = item["value"].encode("utf-8") if item["type"] == "STRING" else item["value"]
            enc_payloads.append({"value": aes_encrypt(data, txn_key)})

        return {
            "encPayloads": enc_payloads,
            "encTxnKey": rsa_encrypt(client_pub, txn_key),
            "cryptoSessionId": session_id,
        }
