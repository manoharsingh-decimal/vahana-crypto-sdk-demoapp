import base64
import json
import logging
import uuid

from .crypto import aes_decrypt, aes_encrypt, rsa_decrypt, rsa_encrypt, rsa_sign_v2
from .exceptions import InvalidEnvelopeException
from .session_store import CryptoSessionStore

logger = logging.getLogger(__name__)


class VahanaCryptoSdkV2:
    """
    T2 variant of the Vahana backend SDK.

    A shared AES key (txnKeyS) is negotiated once during the handshake and stored
    in the session.  All subsequent request/response payloads are encrypted with
    plain AES-256-GCM — no per-request RSA wrapping.  This is faster than T1
    while maintaining equivalent security.

    Constructor args:
        private_key      – PEM of the server long-lived RSA private key
        session_store    – CryptoSessionStore implementation (injected)
        txn_key_name     – envelope field name for the encrypted txn key (default "txnKey")
        payload_key_name – envelope field name for the encrypted payload (default "payload")
    """

    def __init__(
        self,
        private_key: str,
        session_store: CryptoSessionStore,
        txn_key_name: str = "txnKey",
        payload_key_name: str = "payload",
        log_level: str = "INFO",
    ):
        self._priv = private_key
        self._store = session_store
        self._txn_key_name = txn_key_name
        self._payload_key_name = payload_key_name
        logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # ------------------------------------------------------------------
    # Phase 2 — Handshake
    # ------------------------------------------------------------------

    def do_handshake(self, request_body: dict) -> dict:
        """
        Process a T2 handshake request from the frontend.

        Differences from T1:
        - No ephemeral server keypair is generated.
        - A shared txnKeyS (UUID) is stored in the session and sent to the
          frontend RSA-encrypted with the client ephemeral public key.
        - The nonce is signed with the server long-lived private key so the
          frontend can verify against the known long-lived public key.
        - Response payload contains only {signedNonce, cryptoSessionId}.
        """
        logger.debug("Handshake (V2) started")
        enc_key = request_body.get(self._txn_key_name)
        enc_payload = request_body.get(self._payload_key_name)
        if enc_key is None or enc_payload is None:
            logger.error("Handshake (V2) rejected: missing envelope fields")
            raise InvalidEnvelopeException(
                f"Missing required envelope fields: '{self._txn_key_name}' or '{self._payload_key_name}'"
            )

        txn_key = rsa_decrypt(self._priv, enc_key)
        payload = json.loads(aes_decrypt(enc_payload, txn_key))

        guid = payload["guid"]
        nonce = payload["nonce"]
        client_pub = base64.b64decode(payload["clientPubKey"]).decode("utf-8")

        session_id = str(uuid.uuid1())
        txn_key_s = str(uuid.uuid4())

        self._store.set(session_id, {
            "guid": guid,
            "txn_key_s": txn_key_s,
        })
        logger.info("Handshake (V2) complete — session_id=%s guid=%s", session_id, guid)

        resp = {
            "cryptoSessionId": session_id,
            "signedNonce": rsa_sign_v2(self._priv, nonce),
        }

        return {
            self._txn_key_name: rsa_encrypt(client_pub, txn_key_s),
            self._payload_key_name: aes_encrypt(json.dumps(resp).encode("utf-8"), txn_key_s),
        }

    # ------------------------------------------------------------------
    # Phase 3 — Decrypt frontend payloads  (AES-only, no encTxnKey)
    # ------------------------------------------------------------------

    def do_decryption(self, enc_payloads: list, session_id: str) -> list:
        """
        Decrypt payloads sent by the frontend using the shared txnKeyS from the session.

        enc_payloads: list of {"type": "BLOB"|"BINARY"|"STRING", "value": base64_string}
        Returns list of {"type": ..., "value": bytes | str}
        """
        logger.debug("Decrypting %d payload(s) for session %s", len(enc_payloads), session_id)
        session = self._store.get(session_id)
        txn_key_s = session["txn_key_s"]

        result = []
        for item in enc_payloads:
            data = aes_decrypt(item["value"], txn_key_s)
            type_str = item.get("type")
            if type_str is None:
                try:
                    value = data.decode("utf-8")
                    type_str = "STRING"
                except UnicodeDecodeError:
                    value = data
                    type_str = "BINARY"
            else:
                value = data.decode("utf-8") if type_str == "STRING" else data
            result.append({"type": type_str, "value": value})
        return result

    # ------------------------------------------------------------------
    # Phase 4 — Encrypt response payloads  (AES-only, no encTxnKey)
    # ------------------------------------------------------------------

    def do_encryption(self, payloads: list, session_id: str) -> dict:
        """
        Encrypt response payloads for the frontend using the shared txnKeyS.

        payloads: list of {"type": "BLOB"|"BINARY"|"STRING", "value": bytes | str}
        Returns {"encPayloads": [...], "cryptoSessionId": str}
        Note: no "encTxnKey" field — both sides already share txnKeyS.
        """
        logger.debug("Encrypting %d payload(s) for session %s", len(payloads), session_id)
        session = self._store.get(session_id)
        txn_key_s = session["txn_key_s"]

        enc_payloads = []
        for item in payloads:
            data = item["value"].encode("utf-8") if item["type"] == "STRING" else item["value"]
            enc_payloads.append({"value": aes_encrypt(data, txn_key_s)})

        return {
            "encPayloads": enc_payloads,
            "cryptoSessionId": session_id,
        }
