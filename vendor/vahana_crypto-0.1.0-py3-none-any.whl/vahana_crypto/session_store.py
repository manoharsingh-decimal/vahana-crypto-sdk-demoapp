import copy
import json
import threading
from abc import ABC, abstractmethod

from .exceptions import SessionNotFoundException


class CryptoSessionStore(ABC):
    @abstractmethod
    def get(self, session_id: str) -> dict:
        """Return session dict or raise SessionNotFoundException."""

    @abstractmethod
    def set(self, session_id: str, data: dict) -> None:
        """Store session data."""

    @abstractmethod
    def delete(self, session_id: str) -> None:
        """Delete session; no-op if not found."""


class InMemoryCryptoSessionStore(CryptoSessionStore):
    """Thread-safe in-memory store. For dev/test only — no TTL."""

    def __init__(self):
        self._store: dict[str, dict] = {}
        self._lock = threading.Lock()

    def get(self, session_id: str) -> dict:
        with self._lock:
            if session_id not in self._store:
                raise SessionNotFoundException(
                    f"Session not found: {session_id}"
                )
            return copy.deepcopy(self._store[session_id])

    def set(self, session_id: str, data: dict) -> None:
        with self._lock:
            self._store[session_id] = copy.deepcopy(data)

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._store.pop(session_id, None)


class RedisCryptoSessionStore(CryptoSessionStore):
    """
    Redis-backed session store.
    Accepts an injected redis_client (redis-py StrictRedis or Redis).
    """

    def __init__(self, redis_client, ttl_seconds: int = 3600):
        self._redis = redis_client
        self._ttl = ttl_seconds

    def get(self, session_id: str) -> dict:
        raw = self._redis.get(session_id)
        if raw is None:
            raise SessionNotFoundException(f"Session not found: {session_id}")
        return json.loads(raw)

    def set(self, session_id: str, data: dict) -> None:
        self._redis.set(session_id, json.dumps(data), ex=self._ttl)

    def delete(self, session_id: str) -> None:
        self._redis.delete(session_id)


class PostgresCryptoSessionStore(CryptoSessionStore):
    """
    PostgreSQL-backed session store.
    Accepts an injected psycopg2-compatible db_connection.
    Sessions expire after 1 hour.
    """

    _DDL = """
        CREATE TABLE IF NOT EXISTS vahana_crypto_sessions (
            session_id   VARCHAR(64)  PRIMARY KEY,
            session_data JSONB        NOT NULL,
            created_at   TIMESTAMPTZ  DEFAULT NOW(),
            expires_at   TIMESTAMPTZ
        )
    """

    def __init__(self, db_connection):
        self._conn = db_connection
        with self._conn.cursor() as cur:
            cur.execute(self._DDL)
        self._conn.commit()

    def get(self, session_id: str) -> dict:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT session_data FROM vahana_crypto_sessions
                WHERE session_id = %s
                  AND (expires_at IS NULL OR expires_at > NOW())
                """,
                (session_id,),
            )
            row = cur.fetchone()
        if row is None:
            raise SessionNotFoundException(f"Session not found: {session_id}")
        return row[0] if isinstance(row[0], dict) else json.loads(row[0])

    def set(self, session_id: str, data: dict) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO vahana_crypto_sessions (session_id, session_data, expires_at)
                VALUES (%s, %s::jsonb, NOW() + INTERVAL '1 hour')
                ON CONFLICT (session_id) DO UPDATE
                    SET session_data = EXCLUDED.session_data,
                        expires_at   = EXCLUDED.expires_at
                """,
                (session_id, json.dumps(data)),
            )
        self._conn.commit()

    def delete(self, session_id: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                "DELETE FROM vahana_crypto_sessions WHERE session_id = %s",
                (session_id,),
            )
        self._conn.commit()
