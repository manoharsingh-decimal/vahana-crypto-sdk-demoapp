import { jest } from '@jest/globals'
import { generateRsaKeyPair } from '../src/crypto.js'
import { VahanaCryptoSdk } from '../src/sdk.js'
import { EncryptedPayload, FrontendSdkConfig, HandshakeFailedError, Payload } from '../src/types.js'

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

type MockFetch = { fn: ReturnType<typeof jest.fn>; impl: typeof globalThis.fetch }

async function buildHandshakeMockFetch(
  config: FrontendSdkConfig,
  serverKeyPair: { privateKeyPem: string; publicKeyPem: string }
): Promise<MockFetch> {
  const { rsaDecrypt, aesDecrypt, generateRsaKeyPair: gen, aesEncrypt, rsaEncrypt, rsaSign } =
    await import('../src/crypto.js')

  const impl: typeof globalThis.fetch = async (_url, init) => {
    const body = JSON.parse((init as RequestInit).body as string)
    const txnKey = await rsaDecrypt(serverKeyPair.privateKeyPem, body[config.txnKeyName])
    const payloadBytes = await aesDecrypt(body[config.payloadKeyName], txnKey)
    const payload = JSON.parse(new TextDecoder().decode(payloadBytes))
    const clientPub = atob(payload.clientPubKey)

    const ephemeral = await gen()
    const sessionId = 'test-session-id-' + Math.random().toString(36).slice(2)
    const respPayload = {
      serverPubKey: btoa(ephemeral.publicKeyPem),
      cryptoSessionId: sessionId,
      signedNonce: await rsaSign(ephemeral.privateKeyPem, payload.nonce),
    }
    const respKey = crypto.randomUUID()
    return new Response(
      JSON.stringify({
        [config.txnKeyName]: await rsaEncrypt(clientPub, respKey),
        [config.payloadKeyName]: await aesEncrypt(
          new TextEncoder().encode(JSON.stringify(respPayload)),
          respKey
        ),
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    )
  }

  const fn = jest.fn(impl as any) as ReturnType<typeof jest.fn>
  return { fn, impl }
}

function makeConfig(overrides: Partial<FrontendSdkConfig> = {}): FrontendSdkConfig {
  return {
    baseUri: 'https://api.example.com',
    handshakeEndpoint: '/handshake',
    publicKey: '',
    txnKeyName: 'txnKey',
    payloadKeyName: 'payload',
    ...overrides,
  }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('handshake (triggered internally by doEncryption)', () => {
  let serverKeyPair: { privateKeyPem: string; publicKeyPem: string }
  const dummyPayloads: Payload[] = [{ type: 'STRING', value: 'ping' }]

  beforeAll(async () => {
    serverKeyPair = await generateRsaKeyPair()
  }, 30_000)

  test('success: doEncryption triggers handshake and returns a cryptoSessionId', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)
    const { fn } = await buildHandshakeMockFetch(config, serverKeyPair)
    globalThis.fetch = fn as any

    const result = await sdk.doEncryption(dummyPayloads)
    expect(typeof result.cryptoSessionId).toBe('string')
    expect(result.cryptoSessionId.length).toBeGreaterThan(0)
    expect(fn).toHaveBeenCalledTimes(1)
  }, 60_000)

  test('deduplication: two simultaneous doEncryption() calls only fire one handshake request', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)
    const { fn } = await buildHandshakeMockFetch(config, serverKeyPair)
    globalThis.fetch = fn as any

    const [r1, r2] = await Promise.all([sdk.doEncryption(dummyPayloads), sdk.doEncryption(dummyPayloads)])
    expect(r1.cryptoSessionId).toBe(r2.cryptoSessionId)
    expect(fn).toHaveBeenCalledTimes(1)
  }, 60_000)

  test('SUCCESS state: subsequent doEncryption() calls reuse session without extra fetch', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)
    const { fn } = await buildHandshakeMockFetch(config, serverKeyPair)
    globalThis.fetch = fn as any

    await sdk.doEncryption(dummyPayloads)
    await sdk.doEncryption(dummyPayloads)
    expect(fn).toHaveBeenCalledTimes(1)
  }, 60_000)

  test('FAILED state: subsequent doEncryption() immediately rejects with HandshakeFailedError', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)
    globalThis.fetch = (async () => new Response('error', { status: 500 })) as any

    await expect(sdk.doEncryption(dummyPayloads)).rejects.toBeInstanceOf(HandshakeFailedError)
    await expect(sdk.doEncryption(dummyPayloads)).rejects.toBeInstanceOf(HandshakeFailedError)
  }, 60_000)
})

describe('doEncryption', () => {
  let serverKeyPair: { privateKeyPem: string; publicKeyPem: string }

  beforeAll(async () => {
    serverKeyPair = await generateRsaKeyPair()
  }, 30_000)

  test('calls ensureHandshake and returns EncryptionResult', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)
    const { fn } = await buildHandshakeMockFetch(config, serverKeyPair)
    globalThis.fetch = fn as any

    const payloads: Payload[] = [
      { type: 'STRING', value: 'test string' },
      { type: 'BINARY', value: new TextEncoder().encode('binary data').buffer as ArrayBuffer },
    ]
    const result = await sdk.doEncryption(payloads)

    expect(result.cryptoSessionId).toBeTruthy()
    expect(result.encTxnKey).toBeTruthy()
    expect(result.encPayloads).toHaveLength(2)
    expect(result.encPayloads[0].type).toBe('STRING')
    expect(result.encPayloads[1].type).toBe('BINARY')
    expect(result.encPayloads[0].value).not.toBe('test string')
  }, 60_000)
})

describe('doDecryption', () => {
  let serverKeyPair: { privateKeyPem: string; publicKeyPem: string }

  beforeAll(async () => {
    serverKeyPair = await generateRsaKeyPair()
  }, 30_000)

  test('STRING payload: encrypt then decrypt gives back original', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)

    const { generateRsaKeyPair: gen, rsaEncrypt, aesEncrypt } = await import('../src/crypto.js')
    const kp = await gen()
    ;(sdk as any).handshakeManager.clientPriv = kp.privateKeyPem

    const txnKey = crypto.randomUUID()
    const encTxnKey = await rsaEncrypt(kp.publicKeyPem, txnKey)
    // 0x01 = STRING type byte prepended inside ciphertext
    const encPayloads: EncryptedPayload[] = [{
      type: 'STRING',
      value: await aesEncrypt(new Uint8Array([0x01, ...new TextEncoder().encode('decrypted!')]), txnKey),
    }]

    const decrypted = await sdk.doDecryption(encPayloads, encTxnKey)
    expect(decrypted[0].type).toBe('STRING')
    expect(decrypted[0].value).toBe('decrypted!')
  }, 30_000)

  test('BINARY payload stays as ArrayBuffer', async () => {
    const config = makeConfig({ publicKey: serverKeyPair.publicKeyPem })
    const sdk = new VahanaCryptoSdk(config)

    const { generateRsaKeyPair: gen, rsaEncrypt, aesEncrypt } = await import('../src/crypto.js')
    const kp = await gen()
    ;(sdk as any).handshakeManager.clientPriv = kp.privateKeyPem

    const txnKey = crypto.randomUUID()
    const binaryData = new Uint8Array([0xde, 0xad, 0xbe, 0xef])
    // 0x02 = BINARY type byte prepended inside ciphertext
    const encPayloads: EncryptedPayload[] = [{
      type: 'BINARY',
      value: await aesEncrypt(new Uint8Array([0x02, ...binaryData]), txnKey),
    }]

    const decrypted = await sdk.doDecryption(encPayloads, await rsaEncrypt(kp.publicKeyPem, txnKey))
    expect(decrypted[0].type).toBe('BINARY')
    expect(decrypted[0].value).toBeInstanceOf(ArrayBuffer)
    expect(new Uint8Array(decrypted[0].value as ArrayBuffer)).toEqual(binaryData)
  }, 30_000)
})
