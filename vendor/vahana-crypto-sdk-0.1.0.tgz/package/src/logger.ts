import type { LogLevel } from './types.js'

export class Logger {
  private readonly enabled: Set<LogLevel> | false

  constructor(config: false | LogLevel[] | undefined) {
    this.enabled = config ? new Set(config) : false
  }

  log(level: LogLevel, message: string, data?: unknown): void {
    if (!this.enabled || !this.enabled.has(level)) return
    if (data !== undefined) console.log(`[SDK:${level}] ${message}`, data)
    else console.log(`[SDK:${level}] ${message}`)
  }
}
