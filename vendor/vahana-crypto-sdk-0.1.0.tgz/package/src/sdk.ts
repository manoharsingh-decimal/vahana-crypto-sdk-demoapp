import { aesDecrypt, aesEncrypt, rsaDecrypt, rsaEncrypt } from './crypto.js'
import { HandshakeManager } from './handshake.js'
import { HandshakeManagerV2 } from './handshake_v2.js'
import { DecryptionError, EncryptedPayload, EncryptionResult, FrontendSdkConfig, Payload } from './types.js'

const TYPE_BYTE: Record<string, number> = { STRING: 0x01, BINARY: 0x02, BLOB: 0x03 }
const BYTE_TYPE: Record<number, 'STRING' | 'BINARY' | 'BLOB'> = { 0x01: 'STRING', 0x02: 'BINARY', 0x03: 'BLOB' }

export class VahanaCryptoSdk {
  readonly handshakeManager: HandshakeManager | HandshakeManagerV2
  readonly version: 't1' | 't2'

  constructor(config: FrontendSdkConfig) {
    this.version = config.version ?? 't1'
    this.handshakeManager = this.version === 't1'
      ? new HandshakeManager(config)
      : new HandshakeManagerV2(config)
  }

  async doEncryption(payloads: Payload[]): Promise<EncryptionResult>
  async doEncryption(payload: Blob): Promise<EncryptionResult>
  async doEncryption(payload: ArrayBuffer): Promise<EncryptionResult>
  async doEncryption(input: Payload[] | Blob | ArrayBuffer): Promise<EncryptionResult> {
    const payloads: Payload[] = Array.isArray(input)
      ? input
      : input instanceof Blob
        ? [{ type: 'BLOB', value: input }]
        : [{ type: 'BINARY', value: input as ArrayBuffer }]

    const cryptoSessionId = await this.handshakeManager.ensureHandshake()

    if (this.version === 't1') {
      const hm = this.handshakeManager as HandshakeManager
      const txnKey = globalThis.crypto.randomUUID()
      const encTxnKey = await rsaEncrypt(hm.serverPub!, txnKey)
      const encPayloads: EncryptedPayload[] = await Promise.all(
        payloads.map(async p => ({
          value: await aesEncrypt(await serializePayloadWithType(p), txnKey),
        }))
      )
      return { encPayloads, encTxnKey, cryptoSessionId }
    } else {
      const hm = this.handshakeManager as HandshakeManagerV2
      const encPayloads: EncryptedPayload[] = await Promise.all(
        payloads.map(async p => ({
          value: await aesEncrypt(await serializePayloadWithType(p), hm.txnKeyS!),
        }))
      )
      return { encPayloads, cryptoSessionId }
    }
  }

  async doDecryption(encPayloads: EncryptedPayload[], encTxnKey?: string): Promise<Payload[]> {
    let txnKey: string
    if (this.version === 't1') {
      const hm = this.handshakeManager as HandshakeManager
      if (!hm.clientPriv) throw new DecryptionError('Session state invalid: clientPriv not present')
      if (!encTxnKey) throw new DecryptionError('encTxnKey required for T1 decryption')
      txnKey = await rsaDecrypt(hm.clientPriv, encTxnKey)
    } else {
      const hm = this.handshakeManager as HandshakeManagerV2
      if (!hm.txnKeyS) throw new DecryptionError('Session state invalid: txnKeyS not present')
      txnKey = hm.txnKeyS
    }

    return Promise.all(
      encPayloads.map(async item => {
        const raw = await aesDecrypt(item.value, txnKey)
        const type = BYTE_TYPE[raw[0]] ?? 'BINARY'
        const data = raw.slice(1)
        return type === 'STRING'
          ? { type, value: new TextDecoder().decode(data) }
          : { type, value: data.buffer as ArrayBuffer }
      })
    )
  }
}

async function serializePayloadWithType(p: Payload): Promise<Uint8Array> {
  let data: Uint8Array
  if (p.type === 'STRING') data = new TextEncoder().encode(p.value as string)
  else if (p.type === 'BINARY') data = new Uint8Array(p.value as ArrayBuffer)
  else data = new Uint8Array(await (p.value as Blob).arrayBuffer())
  const result = new Uint8Array(1 + data.length)
  result[0] = TYPE_BYTE[p.type] ?? 0x02
  result.set(data, 1)
  return result
}
