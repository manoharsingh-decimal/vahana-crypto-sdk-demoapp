import { aesDecrypt, aesEncrypt, rsaDecrypt, rsaEncrypt } from './crypto.js'
import { HandshakeManager } from './handshake.js'
import { DecryptionError, EncryptedPayload, EncryptionResult, FrontendSdkConfig, Payload } from './types.js'

const TYPE_BYTE: Record<string, number> = { STRING: 0x01, BINARY: 0x02, BLOB: 0x03 }
const BYTE_TYPE: Record<number, 'STRING' | 'BINARY' | 'BLOB'> = { 0x01: 'STRING', 0x02: 'BINARY', 0x03: 'BLOB' }

export class VahanaCryptoSdk {
  private readonly handshakeManager: HandshakeManager

  constructor(config: FrontendSdkConfig) {
    this.handshakeManager = new HandshakeManager(config)
  }

  // ------------------------------------------------------------------
  // Phase 3 — Frontend encrypts payloads for backend
  // ------------------------------------------------------------------

  async doEncryption(payloads: Payload[]): Promise<EncryptionResult>
  async doEncryption(payload: Blob): Promise<EncryptionResult>
  async doEncryption(payload: ArrayBuffer): Promise<EncryptionResult>
  async doEncryption(input: Payload[] | Blob | ArrayBuffer): Promise<EncryptionResult> {
    const payloads: Payload[] = Array.isArray(input)
      ? input
      : input instanceof Blob
        ? [{ type: 'BLOB', value: input }]
        : [{ type: 'BINARY', value: input as ArrayBuffer }]

    const cryptoSessionId = await this.handshakeManager.ensureHandshake()
    const serverPub = this.handshakeManager.serverPub!

    const txnKey = globalThis.crypto.randomUUID()
    const encTxnKey = await rsaEncrypt(serverPub, txnKey)

    const encPayloads: EncryptedPayload[] = await Promise.all(
      payloads.map(async p => ({
        value: await aesEncrypt(await serializePayloadWithType(p), txnKey),
      }))
    )

    return { encPayloads, encTxnKey, cryptoSessionId }
  }

  // ------------------------------------------------------------------
  // Phase 4 — Frontend decrypts backend response
  // ------------------------------------------------------------------

  async doDecryption(encPayloads: EncryptedPayload[], encTxnKey: string): Promise<Payload[]> {
    const clientPriv = this.handshakeManager.clientPriv
    if (!clientPriv) throw new DecryptionError('Session state invalid: clientPriv not present')

    const txnKey = await rsaDecrypt(clientPriv, encTxnKey)

    return Promise.all(
      encPayloads.map(async item => {
        const raw = await aesDecrypt(item.value, txnKey)
        const type = BYTE_TYPE[raw[0]] ?? 'BINARY'
        const data = raw.slice(1)
        return type === 'STRING'
          ? { type, value: new TextDecoder().decode(data) }
          : { type, value: data.buffer as ArrayBuffer }
      })
    )
  }

}

async function serializePayloadWithType(p: Payload): Promise<Uint8Array> {
  let data: Uint8Array
  if (p.type === 'STRING') data = new TextEncoder().encode(p.value as string)
  else if (p.type === 'BINARY') data = new Uint8Array(p.value as ArrayBuffer)
  else data = new Uint8Array(await (p.value as Blob).arrayBuffer())
  const result = new Uint8Array(1 + data.length)
  result[0] = TYPE_BYTE[p.type] ?? 0x02
  result.set(data, 1)
  return result
}
