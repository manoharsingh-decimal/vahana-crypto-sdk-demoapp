import { aesDecrypt, aesEncrypt, generateRsaKeyPair, rsaDecrypt, rsaEncrypt, rsaVerify } from './crypto.js'
import { Logger } from './logger.js'
import { FrontendSdkConfig, HandshakeFailedError } from './types.js'

type HandshakeState = 'NOT_STARTED' | 'IN_PROGRESS' | 'SUCCESS' | 'FAILED'

type Listener = {
  resolve: (sessionId: string) => void
  reject: (err: HandshakeFailedError) => void
}

function randomHex(length: number): string {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(Math.ceil(length / 2)))
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, length)
}

async function browserFingerprint(): Promise<string> {
  const raw = [
    navigator.userAgent,
    navigator.language,
    navigator.languages?.join(',') ?? '',
    String(screen.width),
    String(screen.height),
    String(screen.colorDepth),
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    String(navigator.hardwareConcurrency ?? ''),
    navigator.platform ?? '',
  ].join('|')

  const buffer = await globalThis.crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(raw),
  )
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

export class HandshakeManagerV2 {
  private state: HandshakeState = 'NOT_STARTED'
  private listeners: Listener[] = []
  private readonly logger: Logger

  sessionId: string | null = null
  txnKeyS: string | null = null
  lastReqPayload: Record<string, unknown> | null = null
  lastRespPayload: Record<string, unknown> | null = null

  constructor(private readonly config: FrontendSdkConfig) {
    this.logger = new Logger(config.logging)
  }

  async ensureHandshake(): Promise<string> {
    if (this.state === 'SUCCESS') return this.sessionId!
    if (this.state === 'FAILED') throw new HandshakeFailedError('Handshake is in FAILED state')
    if (this.state === 'IN_PROGRESS') {
      return new Promise<string>((resolve, reject) => {
        this.listeners.push({ resolve, reject })
      })
    }

    this.state = 'IN_PROGRESS'
    try {
      const { privateKeyPem: clientPriv, publicKeyPem: clientPub } = await generateRsaKeyPair()

      const txnKey = globalThis.crypto.randomUUID()
      const guid = await browserFingerprint()
      const nonce = `${Date.now()}-${randomHex(16)}`

      const clientPubB64 = btoa(clientPub)
      const payload = { guid, nonce, clientPubKey: clientPubB64 }
      this.lastReqPayload = { guid, nonce, clientPubKey: clientPubB64.slice(0, 40) + '…' }
      this.logger.log('handshake', 'T2 request', { guid, nonce })

      const encKey = await rsaEncrypt(this.config.publicKey, txnKey)
      const encPayload = await aesEncrypt(
        new TextEncoder().encode(JSON.stringify(payload)),
        txnKey
      )

      const url = this.config.baseUri + this.config.handshakeEndpoint
      this.logger.log('fetch', `POST ${url}`)
      const httpResp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          [this.config.txnKeyName]: encKey,
          [this.config.payloadKeyName]: encPayload,
        }),
      })
      this.logger.log('fetch', `${httpResp.status} ${httpResp.statusText}`)

      if (!httpResp.ok) throw new Error(`Handshake HTTP error: ${httpResp.status}`)

      const resp = await httpResp.json()

      // Backend sends txnKeyS RSA-encrypted under clientPub, payload AES-encrypted under txnKeyS
      this.txnKeyS = await rsaDecrypt(clientPriv, resp[this.config.txnKeyName])
      const raw = await aesDecrypt(resp[this.config.payloadKeyName], this.txnKeyS)
      const respPayload = JSON.parse(new TextDecoder().decode(raw))
      this.lastRespPayload = { cryptoSessionId: respPayload.cryptoSessionId, signedNonce: respPayload.signedNonce }
      this.logger.log('handshake', 'T2 response', { cryptoSessionId: respPayload.cryptoSessionId, signedNonce: respPayload.signedNonce })

      // Verify nonce signature against the long-lived server public key
      const valid = await rsaVerify(this.config.publicKey, nonce, respPayload.signedNonce)
      if (!valid) throw new Error('Nonce signature verification failed — possible MITM')

      this.sessionId = respPayload.cryptoSessionId
      this.state = 'SUCCESS'

      const id = this.sessionId!
      for (const l of this.listeners) l.resolve(id)
      this.listeners = []
      return id
    } catch (e) {
      this.logger.log('error', 'T2 handshake failed', e)
      this.state = 'FAILED'
      const err = new HandshakeFailedError('Handshake failed', e)
      for (const l of this.listeners) l.reject(err)
      this.listeners = []
      throw err
    }
  }
}
