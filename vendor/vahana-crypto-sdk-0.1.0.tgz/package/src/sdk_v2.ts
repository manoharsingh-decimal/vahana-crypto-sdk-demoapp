import { aesDecrypt, aesEncrypt } from './crypto.js'
import { HandshakeManagerV2 } from './handshake_v2.js'
import { DecryptionError, EncryptedPayload, EncryptionResult, FrontendSdkConfig, Payload } from './types.js'

const TYPE_BYTE: Record<string, number> = { STRING: 0x01, BINARY: 0x02, BLOB: 0x03 }
const BYTE_TYPE: Record<number, 'STRING' | 'BINARY' | 'BLOB'> = { 0x01: 'STRING', 0x02: 'BINARY', 0x03: 'BLOB' }

export class VahanaCryptoSdkV2 {
  private readonly handshakeManager: HandshakeManagerV2

  constructor(config: FrontendSdkConfig) {
    this.handshakeManager = new HandshakeManagerV2(config)
  }

  // ------------------------------------------------------------------
  // Phase 3 — Frontend encrypts payloads for backend  (AES-only)
  // ------------------------------------------------------------------

  async doEncryption(payloads: Payload[]): Promise<EncryptionResult>
  async doEncryption(payload: Blob): Promise<EncryptionResult>
  async doEncryption(payload: ArrayBuffer): Promise<EncryptionResult>
  async doEncryption(input: Payload[] | Blob | ArrayBuffer): Promise<EncryptionResult> {
    const payloads: Payload[] = Array.isArray(input)
      ? input
      : input instanceof Blob
        ? [{ type: 'BLOB', value: input }]
        : [{ type: 'BINARY', value: input as ArrayBuffer }]

    const cryptoSessionId = await this.handshakeManager.ensureHandshake()
    const txnKeyS = this.handshakeManager.txnKeyS!

    const encPayloads: EncryptedPayload[] = await Promise.all(
      payloads.map(async p => ({
        value: await aesEncrypt(await serializePayloadWithType(p), txnKeyS),
      }))
    )

    return { encPayloads, cryptoSessionId }
  }

  // ------------------------------------------------------------------
  // Phase 4 — Frontend decrypts backend response  (AES-only)
  // ------------------------------------------------------------------

  async doDecryption(encPayloads: EncryptedPayload[]): Promise<Payload[]> {
    const txnKeyS = this.handshakeManager.txnKeyS
    if (!txnKeyS) throw new DecryptionError('Session state invalid: txnKeyS not present')

    return Promise.all(
      encPayloads.map(async item => {
        const raw = await aesDecrypt(item.value, txnKeyS)
        const type = BYTE_TYPE[raw[0]] ?? 'BINARY'
        const data = raw.slice(1)
        return type === 'STRING'
          ? { type, value: new TextDecoder().decode(data) }
          : { type, value: data.buffer as ArrayBuffer }
      })
    )
  }

}

async function serializePayloadWithType(p: Payload): Promise<Uint8Array> {
  let data: Uint8Array
  if (p.type === 'STRING') data = new TextEncoder().encode(p.value as string)
  else if (p.type === 'BINARY') data = new Uint8Array(p.value as ArrayBuffer)
  else data = new Uint8Array(await (p.value as Blob).arrayBuffer())
  const result = new Uint8Array(1 + data.length)
  result[0] = TYPE_BYTE[p.type] ?? 0x02
  result.set(data, 1)
  return result
}
