import React, { createContext, useContext, useRef } from 'react'
import { VahanaCryptoSdk, FrontendSdkConfig } from 'vahana-crypto-sdk'

export type VahanaCryptoContextValue = {
  sdk: VahanaCryptoSdk
}

export const VahanaCryptoContext = createContext<VahanaCryptoContextValue | null>(null)

type Props = { config: FrontendSdkConfig; children: React.ReactNode }

export function VahanaCryptoProvider({ config, children }: Props) {
  const sdkRef = useRef(new VahanaCryptoSdk(config))

  return (
    <VahanaCryptoContext.Provider value={{ sdk: sdkRef.current }}>
      {children}
    </VahanaCryptoContext.Provider>
  )
}

export function useVahanaCrypto(): VahanaCryptoContextValue {
  const ctx = useContext(VahanaCryptoContext)
  if (!ctx) throw new Error('useVahanaCrypto must be used inside <VahanaCryptoProvider>')
  return ctx
}
