import { useCallback, useState } from 'react'
import type { EncryptedPayload, EncryptionResult, Payload } from 'vahana-crypto-sdk'
import { useVahanaCrypto } from './context.js'

export function useEncryption() {
  const { sdk } = useVahanaCrypto()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const encrypt = useCallback(
    async (payloads: Payload[]): Promise<EncryptionResult | null> => {
      setLoading(true)
      setError(null)
      try {
        return await sdk.doEncryption(payloads)
      } catch (e) {
        setError(e as Error)
        return null
      } finally {
        setLoading(false)
      }
    },
    [sdk]
  )

  return { encrypt, loading, error }
}

export function useDecryption() {
  const { sdk } = useVahanaCrypto()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const decrypt = useCallback(
    async (encPayloads: EncryptedPayload[], encTxnKey: string): Promise<Payload[] | null> => {
      setLoading(true)
      setError(null)
      try {
        return await sdk.doDecryption(encPayloads, encTxnKey)
      } catch (e) {
        setError(e as Error)
        return null
      } finally {
        setLoading(false)
      }
    },
    [sdk]
  )

  return { decrypt, loading, error }
}
