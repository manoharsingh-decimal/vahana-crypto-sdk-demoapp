import { useCallback, useState } from 'react'
import type { EncryptedPayload, EncryptionResultV2, Payload } from 'vahana-crypto-sdk'
import { useVahanaCryptoV2 } from './context_v2.js'

/** T2 hook — doEncryption returns no encTxnKey (pure AES, shared txnKeyS). */
export function useEncryptionV2() {
  const { sdk } = useVahanaCryptoV2()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const encrypt = useCallback(
    async (payloads: Payload[]): Promise<EncryptionResultV2 | null> => {
      setLoading(true)
      setError(null)
      try {
        return await sdk.doEncryption(payloads)
      } catch (e) {
        setError(e as Error)
        return null
      } finally {
        setLoading(false)
      }
    },
    [sdk]
  )

  return { encrypt, loading, error }
}

/** T2 hook — doDecryption takes only encPayloads (no encTxnKey parameter). */
export function useDecryptionV2() {
  const { sdk } = useVahanaCryptoV2()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const decrypt = useCallback(
    async (encPayloads: EncryptedPayload[]): Promise<Payload[] | null> => {
      setLoading(true)
      setError(null)
      try {
        return await sdk.doDecryption(encPayloads)
      } catch (e) {
        setError(e as Error)
        return null
      } finally {
        setLoading(false)
      }
    },
    [sdk]
  )

  return { decrypt, loading, error }
}
