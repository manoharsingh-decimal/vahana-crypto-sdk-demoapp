import React, { createContext, useContext, useRef } from 'react'
import { VahanaCryptoSdkV2, FrontendSdkConfig } from 'vahana-crypto-sdk'

export type VahanaCryptoContextV2Value = {
  sdk: VahanaCryptoSdkV2
}

export const VahanaCryptoContextV2 = createContext<VahanaCryptoContextV2Value | null>(null)

type Props = { config: FrontendSdkConfig; children: React.ReactNode }

export function VahanaCryptoProviderV2({ config, children }: Props) {
  const sdkRef = useRef(new VahanaCryptoSdkV2(config))

  return (
    <VahanaCryptoContextV2.Provider value={{ sdk: sdkRef.current }}>
      {children}
    </VahanaCryptoContextV2.Provider>
  )
}

export function useVahanaCryptoV2(): VahanaCryptoContextV2Value {
  const ctx = useContext(VahanaCryptoContextV2)
  if (!ctx) throw new Error('useVahanaCryptoV2 must be used inside <VahanaCryptoProviderV2>')
  return ctx
}
