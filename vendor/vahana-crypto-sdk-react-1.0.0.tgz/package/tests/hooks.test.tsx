import { jest, describe, test, expect, beforeEach } from '@jest/globals'
import React from 'react'
import { act, renderHook, waitFor } from '@testing-library/react'
import type { EncryptionResult, Payload } from 'vahana-crypto-sdk'

// ---------------------------------------------------------------------------
// ESM-safe mocking: define functions first, then register the module mock.
// jest.mock() factory hoisting runs before const declarations, so
// jest.unstable_mockModule + top-level await import is the correct ESM pattern.
// ---------------------------------------------------------------------------

const mockEnsureHandshake = jest.fn<() => Promise<string>>()
const mockDoEncryption = jest.fn<(p: Payload[]) => Promise<EncryptionResult>>()
const mockDoDecryption = jest.fn<(p: Payload[], k: string) => Promise<Payload[]>>()

jest.unstable_mockModule('vahana-crypto-sdk', () => ({
  VahanaCryptoSdk: jest.fn(() => ({
    ensureHandshake: mockEnsureHandshake,
    doEncryption: mockDoEncryption,
    doDecryption: mockDoDecryption,
  })),
}))

// Dynamic imports MUST come after unstable_mockModule so they pick up the mock.
const { VahanaCryptoProvider, useVahanaCrypto } = await import('../src/context.js')
const { useEncryption, useDecryption } = await import('../src/hooks.js')

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const mockConfig = {
  baseUri: 'https://api.example.com',
  handshakeEndpoint: '/handshake',
  publicKey: 'mock-pub-key',
  txnKeyName: 'txnKey',
  payloadKeyName: 'payload',
}

function wrapper({ children }: { children: React.ReactNode }) {
  return <VahanaCryptoProvider config={mockConfig}>{children}</VahanaCryptoProvider>
}

beforeEach(() => jest.clearAllMocks())

// ---------------------------------------------------------------------------
// VahanaCryptoProvider / useVahanaCrypto
// ---------------------------------------------------------------------------

describe('VahanaCryptoProvider', () => {
  test('starts handshake on mount and sets sessionId on success', async () => {
    mockEnsureHandshake.mockResolvedValueOnce('session-123')

    const { result } = renderHook(() => useVahanaCrypto(), { wrapper })
    expect(result.current.handshakeState).toBe('in_progress')

    await waitFor(() => expect(result.current.handshakeState).toBe('success'))
    expect(result.current.sessionId).toBe('session-123')
    expect(result.current.error).toBeNull()
  })

  test('sets FAILED state and captures error when handshake rejects', async () => {
    const err = new Error('handshake failed')
    mockEnsureHandshake.mockRejectedValueOnce(err)

    const { result } = renderHook(() => useVahanaCrypto(), { wrapper })
    await waitFor(() => expect(result.current.handshakeState).toBe('failed'))

    expect(result.current.sessionId).toBeNull()
    expect(result.current.error).toBe(err)
  })

  test('throws when used outside provider', () => {
    expect(() => renderHook(() => useVahanaCrypto())).toThrow(
      'useVahanaCrypto must be used inside <VahanaCryptoProvider>'
    )
  })
})

// ---------------------------------------------------------------------------
// useEncryption
// ---------------------------------------------------------------------------

describe('useEncryption', () => {
  test('calls sdk.doEncryption and returns result', async () => {
    mockEnsureHandshake.mockResolvedValue('sid')
    const encResult: EncryptionResult = {
      encPayloads: [{ type: 'STRING', value: 'enc-val' }],
      encTxnKey: 'enc-txn-key',
      cryptoSessionId: 'sid',
    }
    mockDoEncryption.mockResolvedValueOnce(encResult)

    const { result } = renderHook(() => useEncryption(), { wrapper })
    let returned: EncryptionResult | null = null
    await act(async () => {
      returned = await result.current.encrypt([{ type: 'STRING', value: 'hello' }])
    })

    expect(returned).toEqual(encResult)
    expect(result.current.loading).toBe(false)
    expect(result.current.error).toBeNull()
  })

  test('sets error and returns null when encryption fails', async () => {
    mockEnsureHandshake.mockResolvedValue('sid')
    const err = new Error('enc failed')
    mockDoEncryption.mockRejectedValueOnce(err)

    const { result } = renderHook(() => useEncryption(), { wrapper })
    let returned: EncryptionResult | null = null
    await act(async () => { returned = await result.current.encrypt([]) })

    expect(returned).toBeNull()
    expect(result.current.error).toBe(err)
    expect(result.current.loading).toBe(false)
  })

  test('loading is true during encryption then clears', async () => {
    mockEnsureHandshake.mockResolvedValue('sid')
    let resolveEnc!: (v: EncryptionResult) => void
    mockDoEncryption.mockReturnValueOnce(new Promise(r => { resolveEnc = r }))

    const { result } = renderHook(() => useEncryption(), { wrapper })

    act(() => { result.current.encrypt([]) })
    await waitFor(() => expect(result.current.loading).toBe(true))

    await act(async () => resolveEnc({ encPayloads: [], encTxnKey: 'k', cryptoSessionId: 's' }))
    expect(result.current.loading).toBe(false)
  })
})

// ---------------------------------------------------------------------------
// useDecryption
// ---------------------------------------------------------------------------

describe('useDecryption', () => {
  test('calls sdk.doDecryption and returns result', async () => {
    mockEnsureHandshake.mockResolvedValue('sid')
    const decResult: Payload[] = [{ type: 'STRING', value: 'plaintext' }]
    mockDoDecryption.mockResolvedValueOnce(decResult)

    const { result } = renderHook(() => useDecryption(), { wrapper })
    let returned: Payload[] | null = null
    await act(async () => {
      returned = await result.current.decrypt([{ type: 'STRING', value: 'enc' }], 'enc-key')
    })

    expect(returned).toEqual(decResult)
    expect(result.current.loading).toBe(false)
    expect(result.current.error).toBeNull()
  })

  test('sets error and returns null when decryption fails', async () => {
    mockEnsureHandshake.mockResolvedValue('sid')
    const err = new Error('dec failed')
    mockDoDecryption.mockRejectedValueOnce(err)

    const { result } = renderHook(() => useDecryption(), { wrapper })
    let returned: Payload[] | null = null
    await act(async () => { returned = await result.current.decrypt([], 'key') })

    expect(returned).toBeNull()
    expect(result.current.error).toBe(err)
  })
})
